const state = { exam: null, answers: {}, index: 0 };
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];

const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[c]));
const linkify = html => html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
const rich = v => linkify(esc(v).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br>"));
const typeset = () => window.MathJax?.typesetPromise?.();

const api = async (url, options = {}) => {
  const res = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  if (!res.ok) {
    let detail = "Request failed";
    try { detail = (await res.json()).detail || detail; } catch {}
    throw new Error(detail);
  }
  return res.json();
};

const toast = message => {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 3200);
};

function showPage(name) {
  $$(".page").forEach(p => p.classList.toggle("active", p.id === name));
  $$(".nav-item").forEach(n => n.classList.toggle("active", n.dataset.page === name));
  $(".nav-links").classList.remove("open");
  if (name === "lectures" && !$("#slide-results").children.length) loadSlides();
  if (name === "reports") loadReports();
  if (name === "exam") loadRuntimeStatus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function populateLectures(lectures) {
  $$(".lecture-select, #exam-lecture").forEach(select => {
    const first = select.options[0].outerHTML;
    select.innerHTML = first + lectures.map(l => `<option value="${l.number}">Lecture ${l.number}</option>`).join("");
  });
}

async function loadOverview() {
  try {
    const o = await api("/api/overview");
    populateLectures(o.lectures);
  } catch { /* lecture list is optional for the rest of the app */ }
}

async function loadRuntimeStatus() {
  const el = $("#runtime-status");
  try {
    const s = await api("/api/runtime/status");
    if (s.ready) {
      el.className = "status-banner ready";
      el.innerHTML = "✓ <strong>Generator ready.</strong> New questions are written and quality-checked against your lecture notes.";
    } else if (s.initializing) {
      el.className = "status-banner";
      el.innerHTML = "⏳ <strong>Warming up the model…</strong> The first exam may take a little longer.";
    } else {
      el.className = "status-banner";
      const need = (s.missing || []).join(", ");
      el.innerHTML = `ℹ️ <strong>Generator loads on first use.</strong> ${need ? "Make sure these are set: " + esc(need) + ". " : ""}You can also choose “Practice from the question bank”.`;
    }
  } catch {
    el.className = "status-banner down";
    el.innerHTML = "⚠️ Could not reach the server. Is the backend running?";
  }
}

/* ---------- EXAM ---------- */
function selected(q) { return state.answers[q.id] || []; }
function toggle(q, letter) {
  const cur = selected(q);
  if (q.question_type === "multi_answer")
    state.answers[q.id] = cur.includes(letter) ? cur.filter(x => x !== letter) : [...cur, letter];
  else state.answers[q.id] = [letter];
  renderQuestion();
}

function renderQuestion() {
  const q = state.exam.questions[state.index];
  const total = state.exam.questions.length;
  const answered = Object.keys(state.answers).length;
  const chosen = selected(q);
  $("#exam-player").innerHTML = `
    <div class="exam-top">
      <strong>Question ${state.index + 1} / ${total}</strong>
      <div class="bar"><span style="width:${(state.index + 1) / total * 100}%"></span></div>
      <strong>${answered} answered</strong>
    </div>
    <article class="card q-card">
      <div class="q-meta">
        <span class="tag">Lecture ${q.lecture || "Mixed"}</span>
        <span class="tag">${esc(q.difficulty)}</span>
        <span class="tag">${esc((q.question_type || "").replace(/_/g, " "))}</span>
      </div>
      <h3>${esc(q.question)}</h3>
      ${q.question_type === "multi_answer" ? '<p class="hint">Select all answers that apply.</p>' : ""}
      ${q.agent_trace ? `<details class="trace"><summary>See how the agents built this (${q.attempts} attempt${q.attempts === 1 ? "" : "s"})</summary><div class="trace-body">${q.agent_trace.map(s => `<strong>${esc(s.agent)}</strong> — ${esc(s.detail)}`).join("<br>")}</div></details>` : ""}
      <div class="opt-list">${Object.entries(q.options).map(([k, t]) =>
        `<button class="opt ${chosen.includes(k) ? "selected" : ""}" data-letter="${k}"><span class="opt-key">${k}</span><span>${esc(t)}</span></button>`).join("")}</div>
      <div class="exam-nav">
        <button class="ghost" id="prev" ${state.index === 0 ? "disabled" : ""}>← Previous</button>
        ${state.index === total - 1
          ? '<button class="primary" id="submit">Submit & get feedback</button>'
          : '<button class="primary" id="next">Next →</button>'}
      </div>
    </article>`;
  $$(".opt").forEach(b => b.onclick = () => toggle(q, b.dataset.letter));
  $("#prev").onclick = () => { state.index--; renderQuestion(); };
  $("#next")?.addEventListener("click", () => { state.index++; renderQuestion(); });
  $("#submit")?.addEventListener("click", submitExam);
  typeset();
}

async function createExam(event) {
  event.preventDefault();
  const config = Object.fromEntries(new FormData(event.target));
  config.count = Number(config.count);
  const btn = $(".form-submit");
  btn.classList.add("btn-busy", "loading"); btn.textContent = "Generating…";
  $("#exam-builder").classList.add("hidden");
  $("#exam-result").classList.add("hidden");
  $("#exam-loading").classList.remove("hidden");
  $("#loading-title").textContent = config.mode === "multi_agent"
    ? "Writing your questions…" : "Picking your questions…";
  $("#loading-sub").textContent = "The generator and review agents are working through your slides. This can take a moment for the first exam while the model warms up.";
  try {
    state.exam = await api("/api/exams/generate", { method: "POST", body: JSON.stringify(config) });
    state.answers = {}; state.index = 0;
    $("#exam-loading").classList.add("hidden");
    $("#exam-player").classList.remove("hidden");
    renderQuestion();
  } catch (error) {
    $("#exam-loading").classList.add("hidden");
    $("#exam-builder").classList.remove("hidden");
    toast(error.message);
    loadRuntimeStatus();
  } finally {
    btn.classList.remove("btn-busy", "loading"); btn.textContent = "Generate my exam";
  }
}

function reviewCard(d, i) {
  const correctSet = new Set(d.correct_letters || []);
  const chosenSet = new Set(d.chosen || []);
  const options = d.options && Object.keys(d.options).length ? d.options : null;
  const optHtml = options ? `<div class="opt-list">${Object.entries(options).map(([k, t]) => {
    const isCorrect = correctSet.has(k);
    const isChosenWrong = chosenSet.has(k) && !isCorrect;
    const cls = isCorrect ? "correct" : (isChosenWrong ? "chosen-wrong" : "");
    const flag = isCorrect ? '<span class="r-flag g">Correct answer</span>'
      : (chosenSet.has(k) ? '<span class="r-flag r">Your answer</span>' : "");
    const why = (!isCorrect && d.why_wrong && d.why_wrong[k])
      ? `<span class="why">Why it's wrong: ${esc(d.why_wrong[k])}</span>` : "";
    return `<div class="r-opt ${cls}"><span class="rk">${k}</span><span>${esc(t)}${why}</span>${flag}</div>`;
  }).join("")}</div>` : `<p><strong>Correct answer:</strong> ${esc(d.correct_answer)}</p>`;

  let resourcesHtml = "";
  if (d.resources && (!Array.isArray(d.resources) || d.resources.length)) {
    const links = Array.isArray(d.resources)
      ? d.resources.map(r => `<a href="${esc(r.url)}" target="_blank" rel="noopener">▶ ${esc(r.title || r.url)}</a>`).join("<br>")
      : rich(d.resources);
    const note = d.resources_note ? `<p>${rich(d.resources_note)}</p>` : "";
    resourcesHtml = `<div class="resources"><strong class="title">📺 Recommended to watch</strong>${note}${links}</div>`;
  }

  return `<article class="card review ${d.correct ? "correct" : ""}">
    <div class="topline">
      <span class="tag">Q${i + 1} · Lecture ${d.lecture || "Mixed"}</span>
      <span class="verdict ${d.correct ? "ok" : "no"}">${d.correct ? "Correct" : "Review this"}</span>
    </div>
    <h4>${esc(d.question)}</h4>
    ${optHtml}
    ${d.explanation ? `<div class="explain"><strong class="title">Explanation</strong>${rich(d.explanation)}</div>` : ""}
    ${resourcesHtml}
    ${(d.evidence_slide_ids || []).length ? `<div class="tags">${d.evidence_slide_ids.map(s => `<span class="tag">${esc(s)}</span>`).join("")}</div>` : ""}
  </article>`;
}

async function submitExam() {
  const missing = state.exam.questions.length - Object.keys(state.answers).length;
  if (missing && !confirm(`${missing} question(s) are unanswered. Submit anyway?`)) return;
  const responses = state.exam.questions.map(q => ({ question_id: q.id, answer: state.answers[q.id] || [] }));
  $("#exam-player").classList.add("hidden");
  $("#exam-loading").classList.remove("hidden");
  $("#loading-title").textContent = "Grading your answers…";
  $("#loading-sub").textContent = "The tutor agent is explaining each answer and finding videos for anything you missed.";
  try {
    const report = await api("/api/exams/submit", { method: "POST", body: JSON.stringify({ exam_id: state.exam.exam_id, responses }) });
    $("#exam-loading").classList.add("hidden");
    $("#exam-result").classList.remove("hidden");
    $("#exam-result").innerHTML = `
      <div class="result-hero">
        <div>
          <span class="mini-label">Exam complete</span>
          <h2>${report.score >= 70 ? "Nice work! 🎉" : "Good effort — here's what to revise"}</h2>
          <p>${rich(report.feedback)}</p>
        </div>
        <div class="result-score">${report.score}%<small>${report.correct}/${report.total} correct</small></div>
      </div>
      <div class="result-bar">
        <h3>Answer-by-answer feedback</h3>
        <button class="primary" id="again">Build another exam</button>
      </div>
      <div class="stack">${report.details.map(reviewCard).join("")}</div>`;
    $("#again").onclick = () => {
      $("#exam-result").classList.add("hidden");
      $("#exam-builder").classList.remove("hidden");
      window.scrollTo({ top: 0, behavior: "smooth" });
    };
    typeset();
  } catch (error) {
    $("#exam-loading").classList.add("hidden");
    $("#exam-player").classList.remove("hidden");
    toast(error.message);
  }
}

/* ---------- TUTOR ---------- */
async function askTutor(event) {
  event.preventDefault();
  const form = event.target;
  const query = form.query.value.trim();
  if (!query) return;
  $("#chat-messages").insertAdjacentHTML("beforeend",
    `<div class="message user"><p>${esc(query)}</p></div><div class="message assistant loading"><p>Searching your lecture notes…</p></div>`);
  form.query.value = "";
  const box = $("#chat-messages"); box.scrollTop = box.scrollHeight;
  const grounded = $("#grounded") ? $("#grounded").checked : true;
  try {
    const result = await api("/api/chat", { method: "POST", body: JSON.stringify({ query, lecture: form.lecture.value ? Number(form.lecture.value) : null, grounded }) });
    $(".message.loading")?.remove();
    const badge = result.grounded === false
      ? '<span class="ground-badge off">RAG tool OFF</span>'
      : '<span class="ground-badge on">Grounded in slides</span>';
    box.insertAdjacentHTML("beforeend",
      `<div class="message assistant">${badge}<p>${rich(result.answer)}</p>${result.disclaimer ? `<small class="disclaimer">${esc(result.disclaimer)}</small>` : ""}</div>`);
    $("#chat-sources").innerHTML = (result.sources || []).length
      ? result.sources.map(s => `<div class="source-item"><strong>${esc(s.slide_id)}</strong> ${esc(s.title)}<small>Lecture ${s.lecture}</small></div>`).join("")
      : '<div class="muted-block">No grounded sources found.</div>';
    box.scrollTop = box.scrollHeight;
    typeset();
  } catch (error) {
    $(".message.loading")?.remove();
    toast(error.message);
  }
}

/* ---------- LECTURES ---------- */
async function loadSlides(event) {
  event?.preventDefault();
  const params = new URLSearchParams(Object.fromEntries(new FormData($("#slide-form"))));
  try {
    const data = await api(`/api/slides?${params}`);
    $("#slide-results").innerHTML = data.items.length ? data.items.map(s => `
      <article class="card slide-card">
        <div class="topline"><span>${esc(s.slide_id)} · Lecture ${s.lecture}</span><span>Slide ${s.slide_number}</span></div>
        <h3>${esc(s.title)}</h3>
        <p>${esc(s.text.slice(0, 480))}${s.text.length > 480 ? "…" : ""}</p>
        <div class="slide-foot"><span class="tag">Lecture note</span><a target="_blank" href="/lectures/${s.lecture}">Open PDF →</a></div>
      </article>`).join("") : '<div class="empty">No matching slides found.</div>';
    typeset();
  } catch (error) { toast(error.message); }
}

/* ---------- REPORTS ---------- */
async function loadReports() {
  try {
    const data = await api("/api/reports");
    $("#report-list").innerHTML = data.items.length ? data.items.map(r => `
      <article class="card report-card">
        <div class="ring" style="--score:${r.score}%"><strong>${r.score}%</strong></div>
        <div>
          <div class="report-meta">${new Date(r.created_at).toLocaleString()} · ${r.correct}/${r.total} correct</div>
          <h3>${r.score >= 70 ? "Solid progress" : "Focused revision recommended"}</h3>
          <p>${rich(r.feedback)}</p>
          <div class="tags">${(r.weak_lectures || []).map(l => `<span class="tag">Review Lecture ${l}</span>`).join("")}${(r.weak_concepts || []).map(c => `<span class="tag">${esc(c)}</span>`).join("")}</div>
        </div>
      </article>`).join("") : '<div class="empty">Complete an exam to see your results and a revision plan here.</div>';
  } catch (error) { toast(error.message); }
}

/* ---------- BOOT ---------- */
document.addEventListener("DOMContentLoaded", () => {
  $$("[data-page]").forEach(el => el.addEventListener("click", e => { e.preventDefault(); showPage(el.dataset.page); }));
  $("#menu-button").onclick = () => $(".nav-links").classList.toggle("open");
  $("#exam-form").onsubmit = createExam;
  $("#chat-form").onsubmit = askTutor;
  $("#slide-form").onsubmit = loadSlides;
  $$(".chip").forEach(chip => chip.onclick = () => { $("#chat-form").query.value = chip.textContent; $("#chat-form").requestSubmit(); });
  loadOverview();
});
