"""GenAI course assistant backend."""

