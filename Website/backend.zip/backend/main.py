from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .course_engine import BLOOMS, DIFFICULTIES, QUESTION_TYPES, engine
from .multi_agent_runtime import RuntimeUnavailable, multi_agent_runtime

BASE_DIR = Path(__file__).resolve().parents[1]
STATIC_DIR = BASE_DIR / "frontend"

app = FastAPI(title="GenAI Course Assistant", version="1.0.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class ExamConfig(BaseModel):
    lecture: int | str | None = "all"
    count: int = Field(default=10, ge=1, le=25)
    difficulty: str = "Mix"
    bloom: str = "Mix"
    question_type: str = "Mix"
    concept: str = ""
    mode: str = "multi_agent"


class ExamSubmission(BaseModel):
    exam_id: str = ""
    responses: list[dict[str, Any]]


class ChatRequest(BaseModel):
    query: str = Field(min_length=2, max_length=1000)
    lecture: int | None = None
    grounded: bool = True


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/lectures/{lecture_number}")
def lecture_pdf(lecture_number: int) -> FileResponse:
    path = BASE_DIR.parent / "Dataset" / "Lectures" / f"LLM Lecture {lecture_number}.pdf"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Lecture PDF not found")
    return FileResponse(path, media_type="application/pdf")


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "questions": len(engine.questions),
        "slides": len(engine.chunks),
        "multi_agent": multi_agent_runtime.status(),
    }


@app.get("/api/runtime/status")
def runtime_status() -> dict[str, Any]:
    return multi_agent_runtime.status()


@app.post("/api/runtime/initialize")
def initialize_runtime() -> dict[str, Any]:
    try:
        multi_agent_runtime.initialize()
        return multi_agent_runtime.status()
    except RuntimeUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/api/runtime/tools")
def runtime_tools() -> dict[str, Any]:
    status = multi_agent_runtime.status()
    return {
        "tools": ["youtube_search", "question_bank_lookup", "slide_lookup_tool", "question_bank_practice"],
        "approved_bank": multi_agent_runtime.bank_stats(),
        "fine_tuned_model": status["fine_tuned_model"],
        "pipeline": status["pipeline"],
    }


@app.get("/api/approved-questions")
def approved_questions(
    concept: str = "",
    difficulty: str = "",
    lecture: int | None = None,
    limit: int = Query(default=20, ge=1, le=100),
) -> dict[str, Any]:
    items = multi_agent_runtime.question_bank_practice(concept, difficulty, lecture, limit)
    return {"items": items, "count": len(items), "stats": multi_agent_runtime.bank_stats()}


@app.get("/api/meta")
def meta() -> dict[str, Any]:
    return {"difficulties": DIFFICULTIES, "blooms": BLOOMS, "question_types": QUESTION_TYPES}


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    return engine.overview()


@app.post("/api/exams/generate")
def generate_exam(config: ExamConfig) -> dict[str, Any]:
    try:
        return engine.generate_exam(config.model_dump())
    except RuntimeUnavailable as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Fine-tuned multi-agent runtime is unavailable: {exc}",
        ) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=f"Multi-agent generation failed: {exc}") from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/exams/submit")
def submit_exam(submission: ExamSubmission) -> dict[str, Any]:
    return engine.submit_exam(submission.model_dump())


@app.get("/api/questions")
def questions(
    lecture: str = "",
    difficulty: str = "",
    bloom: str = "",
    question_type: str = "",
    query: str = "",
    limit: int = Query(default=40, ge=1, le=100),
) -> dict[str, Any]:
    results = engine.search_questions(
        lecture=int(lecture) if lecture else None,
        difficulty=difficulty,
        bloom=bloom,
        question_type=question_type,
        query=query,
        limit=limit,
    )
    return {"items": results, "count": len(results)}


@app.get("/api/slides")
def slides(query: str = "", lecture: str = "", limit: int = Query(default=20, ge=1, le=50)) -> dict[str, Any]:
    results = engine.slide_search(query=query, lecture=int(lecture) if lecture else None, limit=limit)
    return {"items": results, "count": len(results)}


@app.post("/api/chat")
def chat(request: ChatRequest) -> dict[str, Any]:
    try:
        return engine.chat(request.query, request.lecture, request.grounded)
    except RuntimeUnavailable as exc:
        raise HTTPException(status_code=503, detail=f"Hybrid RAG runtime is unavailable: {exc}") from exc


@app.get("/api/youtube")
def youtube(query: str = Query(min_length=2, max_length=200)) -> dict[str, Any]:
    return {"items": engine.youtube_recommendations(query)}


@app.get("/api/reports")
def reports() -> dict[str, Any]:
    return {"items": engine.reports[::-1]}
