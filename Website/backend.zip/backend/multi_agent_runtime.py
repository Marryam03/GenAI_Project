from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import random
import re
import sqlite3
import threading
import urllib.parse
import urllib.request
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any, TypedDict

import numpy as np
import pandas as pd
from rank_bm25 import BM25Okapi

PROJECT_ROOT = Path(os.getenv("PROJECT_ROOT", Path(__file__).resolve().parents[2])).expanduser().resolve()
APP_DIR = Path(__file__).resolve().parents[1]  # the website folder (whatever it is named)
ENV_PATH = next(
    (p for p in (APP_DIR / ".env", PROJECT_ROOT / "website" / ".env") if p.exists()),
    APP_DIR / ".env",
)


def _first_existing(*paths: Path) -> Path:
    for path in paths:
        if path.exists():
            return path
    return paths[0]


CHUNKS_PATH = _first_existing(
    PROJECT_ROOT / "RAG" / "chunks_metadata.json",
    PROJECT_ROOT / "RAG" / "Embeddings" / "chunks_metadata.json",
)
E5_EMBEDDINGS_PATH = CHUNKS_PATH.parent / "embeddings_e5_large.npy"
MCQ_PATH = _first_existing(
    PROJECT_ROOT / "Dataset" / "MCQ Exams" / "llm_mcq_exam_bank.xlsx",
    PROJECT_ROOT / "Dataset" / "MCQ Exam" / "llm_mcq_exam_bank.xlsx",
)
BANK_DB_PATH = PROJECT_ROOT / "question_bank.sqlite"
LLM_CACHE_PATH = PROJECT_ROOT / ".cache" / "llm_cache.json"
FT_REPO = os.getenv("FT_REPO", "Marryam03/mcq-sft-qwen3-4b-lora-v2")
EMBED_MODEL = os.getenv("EMBED_MODEL", "intfloat/multilingual-e5-large")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite")
DISCLAIMER = (
    "This question and explanation are AI-generated from course lecture notes and may contain "
    "errors. Always verify against the original slides and your instructor."
)

# A runnable YouTube Data API fallback (matches the notebook). Rotate before sharing publicly.
YT_API_KEY_FALLBACK = "Youtube API"

DIFFS = ["Beginner", "Intermediate", "Difficult"]
BLOOMS = ["Remember", "Understand", "Apply", "Analyze", "Evaluate", "Create"]
TYPES = ["single_answer", "true_false", "multi_answer"]
MAX_RETRIES = max(1, int(os.getenv("GEN_MAX_RETRIES", "2")))  # critic-driven regenerations
GEN_MAX_TOKENS = int(os.getenv("GEN_MAX_TOKENS", "700"))  # an MCQ JSON is small; cap generation length
ONTOPIC_THRESHOLD = 0.78  # matches the notebook (top dense e5 cosine)
DUP_THRESHOLD = 0.93
GEN_WORKERS = max(1, int(os.getenv("GEN_WORKERS", "3")))  # parallel multi-agent workers


def _load_local_env() -> None:
    if not ENV_PATH.exists():
        return
    for raw_line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_local_env()
FT_REPO = os.getenv("FT_REPO", FT_REPO)
EMBED_MODEL = os.getenv("EMBED_MODEL", EMBED_MODEL)
GEMINI_MODEL = os.getenv("GEMINI_MODEL", GEMINI_MODEL)


def _gemini_keys() -> list[str]:
    """Collect every configured Gemini key so the pool can rotate/fall back across them."""
    raw: list[str] = []
    for name in ("GEMINI_API_KEY", "GEMINI_API_KEY_2", "GEMINI_API_KEY_3", "GEMINI_API_KEY_4"):
        value = os.getenv(name)
        if value:
            raw.append(value.strip())
    multi = os.getenv("GEMINI_API_KEYS", "")
    raw.extend(part.strip() for part in multi.split(",") if part.strip())
    seen: set[str] = set()
    keys: list[str] = []
    for key in raw:
        if key and key not in seen:
            seen.add(key)
            keys.append(key)
    return keys


MCQ_SYSTEM = """You are an exam-question writer for a university course on Generative AI and Large \
Language Models. Given lecture content and a generation specification, produce exactly one \
multiple-choice question in valid JSON format.

Rules:
- Use ONLY information present in the lecture content. Do not invent facts.
- Match the requested question_type exactly:
  * single_answer: 4 options labeled A-D, exactly one correct
  * true_false: 2 options (True / False), exactly one correct
  * multi_answer: 4 or more options, multiple correct (correct_answer lists letters)
- Wrong options must target real misconceptions a student might have.
- Include slide citations in evidence_slide_ids using format L{lecture}-S{slide}.
- Output the JSON object with keys: question, options (map letter->text), correct_answer,
  correct_letter, difficulty, bloom_level, question_type, tested_concepts (list),
  evidence_slide_ids (list of L#-S# strings), why_correct, why_each_wrong_option_is_plausible (map).
- Output ONLY the JSON object. Do not add any text before or after it."""

JSON_REPAIR_SYSTEM = """You are a JSON syntax repair tool. Convert the supplied fine-tuned model
draft into exactly one valid MCQ JSON object. Preserve the draft's question, answers, concepts, and
meaning. Do not invent a different question. Return JSON only with the required MCQ keys."""

PLANNER_SYSTEM = (
    "You are a curriculum planner for a Generative-AI course. Given a topic and a target "
    "difficulty, output a JSON spec with keys: concept, difficulty (Beginner|Intermediate|"
    "Difficult), bloom_level (Remember|Understand|Apply|Analyze|Evaluate|Create), "
    "question_type (single_answer|true_false|multi_answer), and a short retrieval_query. "
    "Pick a bloom_level consistent with the difficulty. Output ONLY JSON."
)

BLUEPRINT_SYSTEM = (
    "You are an exam architect for a Generative-AI course. Given a high-level brief (topics and the "
    "number of questions) compose a BALANCED blueprint: spread the items across Bloom levels "
    "(Remember|Understand|Apply|Analyze|Evaluate|Create), difficulties (Beginner|Intermediate|"
    "Difficult), question types (single_answer|true_false|multi_answer), and the requested concepts "
    'so no single bucket dominates. Output ONLY a JSON object {"items": [ {concept, difficulty, '
    'bloom_level, question_type, retrieval_query}, ... ]} with exactly the requested number of items.'
)

EXAMINER_SYSTEM = (
    "You are a strict exam-quality examiner for a Generative-AI course. You are given an MCQ and the "
    "lecture slide evidence it must be grounded in. Judge it on three axes and answer ONLY with JSON: "
    '{"distractors_plausible": bool, "stem_unambiguous": bool, "answer_supported_by_slides": bool, '
    '"issues": [short strings], "verdict": "pass"|"fail"}. '
    "distractors_plausible is false if any wrong option is silly/obviously-wrong (e.g. unrelated words, "
    "tautologies) rather than a real misconception. stem_unambiguous is false if more than one option "
    "could defensibly be correct or the wording is vague. answer_supported_by_slides is false if the "
    "marked-correct option is not actually supported by the provided slide text. verdict is \"fail\" if "
    "ANY axis is false. Be conservative: only pass genuinely good questions."
)

DISTRACTOR_SYSTEM = (
    "You are a distractor specialist for Generative-AI MCQs. Given a question stem, the correct "
    "answer, the target concept, lecture evidence, and example real-student misconceptions, write "
    "replacement WRONG options. Rules: each distractor must be a plausible misconception a student "
    "could hold (grounded in the concept, not random), must be clearly INCORRECT given the slides, "
    "must be mutually distinct and distinct from the correct answer, and must be SIMILAR IN LENGTH "
    "and specificity to the correct answer (never make the correct option the obviously longest). "
    'Output ONLY JSON: {"distractors": [{"text": str, "misconception": str}, ...]} with exactly '
    "the requested count."
)

TUTOR_SYSTEM = (
    "You are a patient tutor for a Generative-AI course. Using ONLY the provided slide "
    "evidence, explain why the student's chosen answer is wrong (if it is) and why the "
    "correct answer is right. Cite slide IDs in square brackets like [L5-S43]. If the "
    "evidence does not cover it, say so rather than guessing. Be concise and encouraging. "
    "If asked anything outside the course material, decline politely."
)

GROUNDEDNESS_SYSTEM = (
    "You verify whether an explanation is supported by the provided lecture slides. Answer ONLY with "
    'JSON: {"supported": bool, "unsupported_claims": [short strings]}. supported is true only if '
    "every substantive factual claim in the explanation is backed by the slide text. List any claim "
    "that is not supported by the slides."
)

RECO_SYSTEM = (
    "You recommend extra learning resources for a Generative-AI course. Use the youtube_search "
    "tool to find 1-2 relevant videos for the concept the student struggled with, then give a "
    "one-line reason for each. Only recommend material relevant to the concept."
)

PROGRESS_SYSTEM = (
    "You are a study-progress advisor for a Generative-AI course. You are given a student's overall "
    "score and a per-lecture / per-concept breakdown of what they got right and wrong. Produce an "
    "encouraging, specific REVISION PLAN: list the weakest lectures to revise first (in priority "
    "order, by lecture number) and, for each, the concepts to focus on. You may CALL TOOLS: "
    "slide_lookup_tool to point at a specific slide, question_bank_lookup to suggest practice "
    "questions for a weak concept, and youtube_search to suggest one video. Keep it concise and "
    "actionable, then end with one sentence of encouragement."
)


class RuntimeUnavailable(RuntimeError):
    pass


class ExamState(TypedDict, total=False):
    topic: str
    requested_spec: dict[str, Any]
    spec: dict[str, Any]
    lecture: int
    hits: list[dict[str, Any]]
    context: str
    relevance: float
    mcq: dict[str, Any]
    critic: dict[str, Any]
    examiner: dict[str, Any]
    attempts: int
    refused: bool
    final_mcq: dict[str, Any]
    trace: list[dict[str, Any]]


def _installed(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


def _extract_json(text: str) -> dict[str, Any] | None:
    start = text.find("{")
    if start < 0:
        return None
    depth, quoted, escaped = 0, False, False
    for index in range(start, len(text)):
        char = text[index]
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == '"':
            quoted = not quoted
        if quoted:
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start : index + 1])
                except json.JSONDecodeError:
                    return None
    return None


def _letters(value: Any) -> list[str]:
    return sorted(set(re.findall(r"[A-E]", str(value).upper())))


def _norm_letters(value: Any) -> list[str]:
    return re.findall(r"[A-Za-z]", str(value).upper()) if value is not None else []


def critique(mcq: Any) -> dict[str, Any]:
    """Deterministic checks. Returns {hard_fail, reasons, mcq} (mcq may be auto-fixed)."""
    required = {"question", "options", "correct_answer", "correct_letter", "question_type"}
    if not isinstance(mcq, dict) or not required.issubset(mcq):
        return {"hard_fail": True, "reasons": ["invalid JSON or missing required keys"], "mcq": mcq}
    reasons, hard = [], False
    options = mcq.get("options") or {}
    qtype = mcq.get("question_type")
    correct = _norm_letters(mcq.get("correct_letter"))
    if qtype == "single_answer" and len(options) != 4:
        hard, reasons = True, reasons + ["single_answer requires four options"]
    if qtype == "true_false" and len(options) != 2:
        hard, reasons = True, reasons + ["true_false requires two options"]
    normalized = [str(value).strip().lower() for value in options.values()]
    if len(normalized) != len(set(normalized)):
        hard, reasons = True, reasons + ["duplicate options"]
    if len(correct) == 1 and correct[0] in options:
        if str(options[correct[0]]).strip() != str(mcq.get("correct_answer", "")).strip():
            mcq = dict(mcq)
            mcq["correct_answer"] = options[correct[0]]
            reasons.append("fixed correct_answer text")
    if qtype == "single_answer" and len(correct) == 1 and correct[0] in options and len(options) > 1:
        if max(options, key=lambda key: len(str(options[key]))) == correct[0]:
            hard, reasons = True, reasons + ["correct option is the longest (length bias)"]
    if qtype == "multi_answer":
        if len(correct) < 2:
            hard, reasons = True, reasons + ["multi_answer requires at least two answers"]
        if any(letter not in options for letter in correct):
            hard, reasons = True, reasons + ["correct_letter references a missing option"]
    return {"hard_fail": hard, "reasons": reasons, "mcq": mcq}


def _rewrite_letter_refs(text: Any, remap: dict[str, str]) -> Any:
    if not isinstance(text, str):
        return text
    return re.compile(r"\b([A-E])([).])").sub(lambda m: remap.get(m.group(1), m.group(1)) + m.group(2), text)


def shuffle_mcq(mcq: dict[str, Any], seed: int | None = None) -> dict[str, Any]:
    """Shuffle option positions and remap correct letters AND per-option rationales."""
    rng = random.Random(seed)
    options = mcq.get("options") or {}
    letters = list(options)
    if len(letters) < 2:
        return mcq
    correct = set(_norm_letters(mcq.get("correct_letter")))
    why_wrong = mcq.get("why_each_wrong_option_is_plausible") or {}
    items = [
        {"L": L, "content": options[L], "is_correct": L in correct, "expl": why_wrong.get(L, "")}
        for L in letters
    ]
    order = list(range(len(items)))
    rng.shuffle(order)
    new_letters = [chr(ord("A") + i) for i in range(len(items))]
    remap, new_options, new_wrong, correct_letters, correct_text = {}, {}, {}, [], []
    for new_index, source_index in enumerate(order):
        new = new_letters[new_index]
        item = items[source_index]
        remap[item["L"]] = new
        new_options[new] = item["content"]
        if item["is_correct"]:
            correct_letters.append(new)
            correct_text.append(item["content"])
        elif item["expl"]:
            new_wrong[new] = item["expl"]
    output = dict(mcq)
    output["options"] = new_options
    output["correct_letter"] = ",".join(correct_letters)
    output["correct_answer"] = ", ".join(correct_text)
    output["why_correct"] = _rewrite_letter_refs(mcq.get("why_correct", ""), remap)
    output["why_each_wrong_option_is_plausible"] = {
        k: _rewrite_letter_refs(v, remap) for k, v in new_wrong.items()
    }
    return output


def _mcq_brief(mcq: dict[str, Any]) -> str:
    options = mcq.get("options") or {}
    correct = set(_norm_letters(mcq.get("correct_letter")))
    lines = [f"Question: {mcq.get('question', '')}", "Options:"]
    lines += [f"  {L}) {options[L]}" + ("   <-- correct" if L in correct else "") for L in options]
    lines.append(f"correct_letter: {mcq.get('correct_letter', '')}")
    return "\n".join(lines)


class _GeminiPool:
    """Round-robin pool of Gemini clients with automatic fallback across keys and a response cache.

    If one key is rate-limited or fails, the call rotates to the next key transparently, so the
    multi-agent pipeline keeps running when a single key is exhausted.
    """

    def __init__(self, keys: list[str]) -> None:
        from google import genai

        if not keys:
            raise RuntimeUnavailable("No Gemini API key configured (set GEMINI_API_KEY).")
        self._clients = [genai.Client(api_key=key) for key in keys]
        self._counter = 0
        self._lock = threading.Lock()
        self._cache_lock = threading.Lock()
        self._cache: dict[str, str] = {}
        if LLM_CACHE_PATH.exists():
            try:
                self._cache = json.loads(LLM_CACHE_PATH.read_text(encoding="utf-8"))
            except Exception:
                self._cache = {}

    @property
    def key_count(self) -> int:
        return len(self._clients)

    def _next_index(self) -> int:
        with self._lock:
            index = self._counter % len(self._clients)
            self._counter += 1
            return index

    def _cache_key(self, *parts: Any) -> str:
        return hashlib.sha1(json.dumps(parts, default=str, sort_keys=True).encode()).hexdigest()

    def _cache_save(self) -> None:
        try:
            LLM_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
            LLM_CACHE_PATH.write_text(json.dumps(self._cache), encoding="utf-8")
        except Exception:
            pass

    def generate(
        self,
        prompt: str,
        system: str,
        json_out: bool = False,
        tools: list[Any] | None = None,
        use_cache: bool = True,
    ) -> str:
        cacheable = use_cache and tools is None
        if cacheable:
            ck = self._cache_key(GEMINI_MODEL, prompt, system, json_out)
            with self._cache_lock:
                if ck in self._cache:
                    return self._cache[ck]
        config: dict[str, Any] = {"system_instruction": system}
        if json_out:
            config["response_mime_type"] = "application/json"
        if tools:
            config["tools"] = tools
        start = self._next_index()
        last_error: Exception | None = None
        for offset in range(len(self._clients)):
            client = self._clients[(start + offset) % len(self._clients)]
            try:
                response = client.models.generate_content(
                    model=GEMINI_MODEL, contents=prompt, config=config
                )
                text = response.text or ""
                if cacheable and text:
                    with self._cache_lock:
                        self._cache[ck] = text
                        self._cache_save()
                return text
            except Exception as exc:  # rotate to the next key on any failure
                last_error = exc
        raise RuntimeError(f"All Gemini keys failed: {last_error}")


class MultiAgentRuntime:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._infer_lock = threading.Lock()  # serializes GPU/Qdrant local inference
        self._bank_lock = threading.Lock()  # serializes SQLite writes
        self._initialized = False
        self._initializing = False
        self._error = ""
        self._model = None
        self._tokenizer = None
        self._stop_ids: list[int] = []
        self._use_ft = False
        self._embedder = None
        self._graph = None
        self._pool: _GeminiPool | None = None
        self._qdrant = None
        self._generator_backend = ""
        self.chunks = json.loads(CHUNKS_PATH.read_text(encoding="utf-8"))
        self.slide_by_id = {chunk["id"]: chunk for chunk in self.chunks}
        self.mcq_df = pd.read_excel(MCQ_PATH, sheet_name="MCQ_Bank").fillna("")
        self.distractor_examples = self._mine_distractors()
        self.embeddings = None
        self.bm25 = BM25Okapi([self._tokenize(chunk["text"]) for chunk in self.chunks])
        self._ensure_bank()

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        return [t for t in re.findall(r"[a-z0-9][a-z0-9\-]*", text.lower()) if len(t) > 1]

    @staticmethod
    def _parse_lettered(blob: Any) -> dict[str, str]:
        output, current = {}, None
        for line in str(blob).splitlines():
            match = re.match(r"^\s*([A-Z])[.)]\s*(.+?)\s*$", line)
            if match:
                current = match.group(1)
                output[current] = match.group(2)
            elif current and line.strip():
                output[current] += " " + line.strip()
        return output

    def _mine_distractors(self) -> dict[str, list[dict[str, str]]]:
        examples: dict[str, list[dict[str, str]]] = defaultdict(list)
        for _, row in self.mcq_df.iterrows():
            options = self._parse_lettered(row["options"])
            notes = self._parse_lettered(row["why_each_wrong_option_is_plausible"])
            correct = set(_letters(row["correct_letter"]))
            for concept in re.split(r"[;,]", str(row["tested_concepts"])):
                concept = concept.strip().lower()
                if concept:
                    examples[concept].extend(
                        {"text": text, "note": notes.get(letter, "")}
                        for letter, text in options.items()
                        if letter not in correct
                    )
        return dict(examples)

    def _bank_distractor_examples(self, concept: str, k: int = 6) -> list[dict[str, str]]:
        concept = (concept or "").lower().strip()
        pool = list(self.distractor_examples.get(concept, []))
        if len(pool) < k:
            tokens = {t for t in re.split(r"\W+", concept) if len(t) > 3}
            for key, items in self.distractor_examples.items():
                if key != concept and tokens & set(re.split(r"\W+", key)):
                    pool.extend(items)
                if len(pool) >= k * 4:
                    break
        random.shuffle(pool)
        seen, out = set(), []
        for item in pool:
            text = item["text"].strip()
            if text and text.lower() not in seen:
                seen.add(text.lower())
                out.append(item)
            if len(out) >= k:
                break
        return out

    def _ensure_bank(self) -> None:
        with sqlite3.connect(BANK_DB_PATH) as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS approved_mcqs (
                id INTEGER PRIMARY KEY AUTOINCREMENT, lecture INTEGER, concept TEXT,
                difficulty TEXT, bloom_level TEXT, question_type TEXT, question TEXT,
                options TEXT, correct_letter TEXT, correct_answer TEXT, evidence_slide_ids TEXT,
                why_correct TEXT, embedding BLOB, created_at TEXT)"""
            )

    def status(self) -> dict[str, Any]:
        try:
            import torch

            cuda = torch.cuda.is_available()
            device = torch.cuda.get_device_name(0) if cuda else "CPU"
        except Exception:
            cuda, device = False, "CPU"
        packages = {
            "langgraph": _installed("langgraph"),
            "peft": _installed("peft"),
            "torch": _installed("torch"),
            "transformers": _installed("transformers"),
            "sentence_transformers": _installed("sentence_transformers"),
            "google_genai": _installed("google.genai"),
            "qdrant_client": _installed("qdrant_client"),
        }
        keys = _gemini_keys()
        return {
            "ready": self._initialized,
            "initializing": self._initializing,
            "error": self._error,
            "gpu": {"cuda_available": cuda, "device": device},
            "fine_tuned_model": {
                "repo": FT_REPO,
                "loaded": self._model is not None,
                "backend": self._generator_backend,
                "use_ft": self._use_ft,
            },
            "hybrid_rag": {"embedding_model": EMBED_MODEL, "loaded": self._embedder is not None},
            "multi_agent": {
                "langgraph_compiled": self._graph is not None,
                "gemini_keys": len(keys),
                "workers": GEN_WORKERS,
            },
            "packages": packages,
            "missing": [name for name, present in packages.items() if not present]
            + ([] if keys else ["GEMINI_API_KEY"]),
            "pipeline": [
                "Curriculum Planner",
                "Hybrid RAG Retriever",
                "On-topic Guard",
                "Refusal Agent",
                "Fine-tuned Qwen3-4B Generator",
                "Distractor Specialist",
                "Deterministic Critic",
                "Gemini Examiner",
                "Rebalance Agent",
                "Finalize and Shuffle",
                "Grounded Feedback Tutor",
                "Progress Report Agent",
            ],
        }

    def initialize(self) -> None:
        if self._initialized:
            return
        with self._lock:
            if self._initialized:
                return
            self._initializing = True
            try:
                missing = [name for name in ("langgraph",) if not _installed(name)]
                if missing:
                    raise RuntimeUnavailable("Missing required packages: " + ", ".join(missing))
                if not _gemini_keys():
                    raise RuntimeUnavailable(
                        "GEMINI_API_KEY is required for Planner, Distractor, and Examiner agents."
                    )
                self._load_reasoning_client()
                self._load_fine_tuned_model()
                self._load_retriever()
                self._compile_graph()
                self._initialized = True
                self._error = ""
            except Exception as exc:
                self._error = str(exc)
                raise RuntimeUnavailable(str(exc)) from exc
            finally:
                self._initializing = False

    def _load_reasoning_client(self) -> None:
        self._pool = _GeminiPool(_gemini_keys())

    def _load_retriever(self) -> None:
        from sentence_transformers import SentenceTransformer

        try:
            import torch

            device = "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            device = "cpu"
        self._embedder = SentenceTransformer(EMBED_MODEL, device=device)
        if E5_EMBEDDINGS_PATH.exists():
            self.embeddings = np.load(E5_EMBEDDINGS_PATH).astype("float32")
        else:
            self.embeddings = self._embedder.encode(
                [f"passage: {chunk['text']}" for chunk in self.chunks],
                batch_size=16,
                normalize_embeddings=True,
                convert_to_numpy=True,
                show_progress_bar=True,
            ).astype("float32")
            np.save(E5_EMBEDDINGS_PATH, self.embeddings)
        if self.embeddings.shape[0] != len(self.chunks):
            raise RuntimeUnavailable("RAG embeddings and chunk metadata have different lengths.")
        from qdrant_client import QdrantClient
        from qdrant_client.models import Distance, PointStruct, VectorParams

        self._qdrant = QdrantClient(":memory:")
        self._qdrant.create_collection(
            collection_name="llm_lecture_notes_e5",
            vectors_config=VectorParams(size=self.embeddings.shape[1], distance=Distance.COSINE),
        )
        self._qdrant.upsert(
            collection_name="llm_lecture_notes_e5",
            points=[
                PointStruct(
                    id=index,
                    vector=self.embeddings[index].tolist(),
                    payload={
                        "lecture": int(chunk["metadata"]["lecture"]),
                        "key_concepts": chunk["metadata"].get("key_concepts", []),
                    },
                )
                for index, chunk in enumerate(self.chunks)
            ],
        )

    def _load_fine_tuned_model(self) -> None:
        """Load the fine-tuned Qwen3-4B generator once. Falls back to the Gemini generator
        (USE_FT=False, same prompt) when no CUDA GPU or PEFT/unsloth stack is available."""
        try:
            import torch

            if not torch.cuda.is_available():
                raise RuntimeUnavailable("no CUDA GPU")
        except RuntimeUnavailable:
            self._use_ft = False
            self._generator_backend = "gemini"
            return
        except Exception:
            self._use_ft = False
            self._generator_backend = "gemini"
            return
        try:
            from unsloth import FastLanguageModel
            from unsloth.chat_templates import get_chat_template

            self._model, self._tokenizer = FastLanguageModel.from_pretrained(
                model_name=FT_REPO, max_seq_length=8192, load_in_4bit=True
            )
            self._tokenizer = get_chat_template(self._tokenizer, chat_template="qwen3")
            FastLanguageModel.for_inference(self._model)
            self._generator_backend = "unsloth"
            self._use_ft = True
        except ImportError:
            from peft import AutoPeftModelForCausalLM
            from transformers import AutoTokenizer

            self._model = AutoPeftModelForCausalLM.from_pretrained(
                FT_REPO, device_map="auto", torch_dtype="auto", load_in_4bit=True
            )
            self._tokenizer = AutoTokenizer.from_pretrained(FT_REPO)
            self._generator_backend = "peft"
            self._use_ft = True
        if self._use_ft:
            self._stop_ids = [
                tid
                for tid in (
                    self._tokenizer.convert_tokens_to_ids("<|im_end|>"),
                    self._tokenizer.eos_token_id,
                )
                if tid is not None and tid >= 0
            ]

    # ---- Gemini helpers ----------------------------------------------------------------
    def _gemini_json(self, prompt: str, system: str, use_cache: bool = True) -> dict[str, Any]:
        raw = self._pool.generate(prompt, system, json_out=True, use_cache=use_cache)
        parsed = _extract_json(raw or "")
        if not parsed:
            raise RuntimeError("Agent returned invalid JSON.")
        return parsed

    def _gemini_text(self, prompt: str, system: str, tools: list[Any] | None = None) -> str:
        return self._pool.generate(prompt, system, tools=tools, use_cache=tools is None)

    # ---- Hybrid RAG --------------------------------------------------------------------
    def _retrieve(self, query: str, lecture: int | None, k: int = 4, concept: str = "") -> list[dict[str, Any]]:
        with self._infer_lock:
            dense_query = self._embedder.encode(
                [f"query: {query}"], normalize_embeddings=True, convert_to_numpy=True
            )[0]
            dense_scores = self.embeddings @ dense_query
            qdrant_rank: list[int] | None = None
            if self._qdrant is not None and not concept:
                try:
                    from qdrant_client.models import FieldCondition, Filter, MatchValue

                    query_filter = (
                        Filter(must=[FieldCondition(key="lecture", match=MatchValue(value=lecture))])
                        if lecture is not None
                        else None
                    )
                    result = self._qdrant.query_points(
                        collection_name="llm_lecture_notes_e5",
                        query=dense_query.tolist(),
                        query_filter=query_filter,
                        limit=50,
                    ).points
                    qdrant_rank = [int(point.id) for point in result]
                except Exception:
                    qdrant_rank = None
        bm25_scores = self.bm25.get_scores(self._tokenize(query))
        allowed = [
            index
            for index, chunk in enumerate(self.chunks)
            if (lecture is None or int(chunk["metadata"]["lecture"]) == lecture)
            and (
                not concept
                or concept.lower()
                in (
                    chunk["metadata"]["slide_title"]
                    + " "
                    + " ".join(chunk["metadata"].get("key_concepts", []))
                ).lower()
            )
        ]
        dense_rank = qdrant_rank if qdrant_rank is not None else sorted(
            allowed, key=lambda i: float(dense_scores[i]), reverse=True
        )
        bm25_rank = sorted(allowed, key=lambda i: float(bm25_scores[i]), reverse=True)
        fused: dict[int, float] = {}
        for rank, index in enumerate(dense_rank[:50]):
            fused[index] = fused.get(index, 0) + 1 / (60 + rank)
        for rank, index in enumerate(bm25_rank[:50]):
            fused[index] = fused.get(index, 0) + 1 / (60 + rank)
        top = sorted(fused, key=fused.get, reverse=True)[:k]
        return [
            {
                "slide_id": self.chunks[i]["id"],
                "title": self.chunks[i]["metadata"]["slide_title"],
                "text": self.chunks[i]["text"],
                "lecture": int(self.chunks[i]["metadata"]["lecture"]),
                "dense_score": float(dense_scores[i]),
            }
            for i in top
        ]

    def _relevance(self, query: str, lecture: int | None) -> float:
        """Top dense e5 cosine in [0,1] for the on-topic / refusal guard (notebook parity)."""
        with self._infer_lock:
            dense_query = self._embedder.encode(
                [f"query: {query}"], normalize_embeddings=True, convert_to_numpy=True
            )[0]
            dense_scores = self.embeddings @ dense_query
        if lecture is None:
            return float(dense_scores.max())
        mask = [
            float(dense_scores[i])
            for i, chunk in enumerate(self.chunks)
            if int(chunk["metadata"]["lecture"]) == lecture
        ]
        return max(mask) if mask else 0.0

    @staticmethod
    def _build_context(hits: list[dict[str, Any]], max_chars: int = 700) -> str:
        return (
            "\n\n".join(f"[{h['slide_id']}: {h['title']}]\n{h['text'][:max_chars]}" for h in hits)
            or "(no slides)"
        )

    # ---- Generator ---------------------------------------------------------------------
    def _generate_with_ft(self, context: str, spec: dict[str, Any]) -> dict[str, Any]:
        user = (
            f"Lecture content:\n{context}\n\nGeneration specification:\n"
            f"- Target concept: {spec['concept']}\n- Difficulty: {spec['difficulty']}\n"
            f"- Bloom level: {spec['bloom_level']}\n- Question type: {spec['question_type']}\n"
            "Generate one MCQ as JSON."
        )
        if not self._use_ft:
            return self._gemini_json(user, MCQ_SYSTEM, use_cache=False)

        import torch

        messages = [{"role": "system", "content": MCQ_SYSTEM}, {"role": "user", "content": user}]
        # Qwen3 emits long <think> blocks by default, which makes each generation huge and slow.
        # MCQ generation needs the JSON, not chain-of-thought, so we disable thinking when supported.
        try:
            prompt = self._tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
            )
        except TypeError:
            prompt = self._tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        last_draft = ""
        for attempt in range(2):
            with self._infer_lock:
                inputs = self._tokenizer(prompt, return_tensors="pt").to(self._model.device)
                generation_kwargs: dict[str, Any] = {
                    "max_new_tokens": GEN_MAX_TOKENS,
                    "eos_token_id": self._stop_ids or self._tokenizer.eos_token_id,
                    "pad_token_id": self._tokenizer.pad_token_id or self._tokenizer.eos_token_id,
                }
                if attempt < 1:
                    generation_kwargs.update(do_sample=True, temperature=0.7, top_p=0.9)
                else:
                    generation_kwargs.update(do_sample=False)
                with torch.inference_mode():
                    output = self._model.generate(**inputs, **generation_kwargs)
                draft = self._tokenizer.decode(
                    output[0][inputs["input_ids"].shape[-1] :], skip_special_tokens=True
                ).strip()
            last_draft = draft
            parsed = _extract_json(draft)
            if parsed:
                return parsed
        repaired = self._gemini_json(
            "Repair this fine-tuned Qwen3-4B draft into valid MCQ JSON without changing its meaning:\n\n"
            + last_draft,
            JSON_REPAIR_SYSTEM,
            use_cache=False,
        )
        if not repaired:
            raise RuntimeError("Fine-tuned generator produced invalid JSON after three attempts and repair.")
        return repaired

    # ---- Quality agents (notebook parity) ----------------------------------------------
    def _distractor_specialist(self, mcq: dict[str, Any], context: str) -> dict[str, Any]:
        """Rewrite only the WRONG options with bank-seeded misconceptions; keep the correct one."""
        if not isinstance(mcq, dict) or mcq.get("question_type") == "true_false":
            return mcq
        options = dict(mcq.get("options") or {})
        correct = set(_norm_letters(mcq.get("correct_letter")))
        wrong_letters = [L for L in options if L not in correct]
        if not wrong_letters:
            return mcq
        correct_text = "; ".join(options[L] for L in options if L in correct) or mcq.get("correct_answer", "")
        concept = str((mcq.get("tested_concepts") or [mcq.get("question", "")])[0])
        seeds = self._bank_distractor_examples(concept, k=6)
        seed_text = "\n".join(
            f"- {d['text']}" + (f"  (misconception: {d['note']})" if d.get("note") else "") for d in seeds
        ) or "(none found)"
        prompt = (
            f"Concept: {concept}\nQuestion: {mcq.get('question', '')}\n"
            f"Correct answer (keep, do NOT reproduce as a distractor): {correct_text}\n"
            f"Number of distractors needed: {len(wrong_letters)}\n\n"
            f"Real student misconceptions for this concept (use as inspiration):\n{seed_text}\n\n"
            f"Lecture evidence:\n{context}\n\nWrite the distractors as JSON."
        )
        try:
            report = self._gemini_json(prompt, DISTRACTOR_SYSTEM, use_cache=False)
        except Exception:
            return mcq
        new = report.get("distractors", []) if isinstance(report, dict) else []
        if not new:
            return mcq
        out = dict(mcq)
        out_options = dict(options)
        why_wrong = dict(mcq.get("why_each_wrong_option_is_plausible") or {})
        taken = {str(options[L]).strip().lower() for L in correct}
        index = 0
        for L in wrong_letters:
            while index < len(new):
                candidate = str(new[index].get("text", "")).strip()
                misconception = new[index].get("misconception")
                index += 1
                if candidate and candidate.lower() not in taken:
                    out_options[L] = candidate
                    taken.add(candidate.lower())
                    if misconception:
                        why_wrong[L] = misconception
                    break
        out["options"] = out_options
        out["why_each_wrong_option_is_plausible"] = why_wrong
        return out

    def _examiner_review(self, mcq: dict[str, Any], context: str) -> dict[str, Any]:
        prompt = f"{_mcq_brief(mcq)}\n\nLecture slide evidence:\n{context}\n\nJudge this MCQ."
        try:
            report = self._gemini_json(prompt, EXAMINER_SYSTEM)
        except Exception as exc:
            return {"verdict": "pass", "issues": [f"examiner_error: {exc}"]}
        if "verdict" not in report:
            return {
                "verdict": "pass",
                "issues": ["examiner_unparsed"],
                "distractors_plausible": True,
                "stem_unambiguous": True,
                "answer_supported_by_slides": True,
            }
        report.setdefault("issues", [])
        return report

    def _rebalance_distractors(self, mcq: dict[str, Any], context: str) -> dict[str, Any]:
        if mcq.get("question_type") != "single_answer":
            return mcq
        options = dict(mcq.get("options") or {})
        correct = _norm_letters(mcq.get("correct_letter"))
        if len(correct) != 1 or correct[0] not in options or len(options) < 2:
            return mcq
        if max(options, key=lambda k: len(str(options[k]))) != correct[0]:
            return mcq
        target = len(str(options[correct[0]]))
        wrong_letters = [L for L in options if L != correct[0]]
        prompt = (
            f"Rewrite each WRONG option so it is about {target} characters long (close to the "
            f"correct answer's length), stays a plausible but INCORRECT answer, and keeps its "
            f"meaning. Do not change the correct answer.\n\nQuestion: {mcq.get('question', '')}\n"
            f"Correct answer: {options[correct[0]]}\n"
            + "\n".join(f"{L}) {options[L]}" for L in wrong_letters)
            + f"\n\nLecture evidence:\n{context}\n\n"
            'Output ONLY JSON mapping each wrong letter to its rewritten text, e.g. {"A": "..."}.'
        )
        try:
            report = self._gemini_json(prompt, DISTRACTOR_SYSTEM, use_cache=False)
        except Exception:
            return mcq
        out = dict(mcq)
        out_options = dict(options)
        for L in wrong_letters:
            if isinstance(report.get(L), str) and report[L].strip():
                out_options[L] = report[L].strip()
        out["options"] = out_options
        return out

    def _verify_groundedness(self, explanation: str, evidence: str, cited_ids: list[str]) -> dict[str, Any]:
        missing = [sid for sid in cited_ids if sid not in self.slide_by_id]
        try:
            report = self._gemini_json(
                f"Slides:\n{evidence}\n\nExplanation:\n{explanation}\n\nIs it supported?",
                GROUNDEDNESS_SYSTEM,
            )
        except Exception:
            report = {}
        supported = bool(report.get("supported", True)) and not missing
        return {
            "ok": supported,
            "missing_slide_ids": missing,
            "unsupported_claims": report.get("unsupported_claims", []),
        }

    @staticmethod
    def _trace(state: ExamState, agent: str, detail: str) -> list[dict[str, Any]]:
        return [*(state.get("trace") or []), {"agent": agent, "detail": detail}]

    def _compile_graph(self) -> None:
        from langgraph.graph import END, StateGraph

        def planner(state: ExamState) -> ExamState:
            requested = state.get("requested_spec") or {}
            if requested.get("concept"):
                spec = dict(requested)
            else:
                spec = self._gemini_json(
                    f"Topic: {state['topic']}\nProduce the spec.", PLANNER_SYSTEM
                )
            spec.setdefault("concept", state["topic"])
            spec.setdefault("difficulty", "Intermediate")
            spec.setdefault("bloom_level", "Apply")
            spec.setdefault("question_type", "single_answer")
            spec.setdefault("retrieval_query", spec.get("concept") or state["topic"])
            return {"spec": spec, "attempts": 0, "trace": self._trace(state, "Curriculum Planner", str(spec))}

        def retriever(state: ExamState) -> ExamState:
            hits = self._retrieve(state["spec"]["retrieval_query"], state.get("lecture"))
            return {
                "hits": hits,
                "context": self._build_context(hits),
                "trace": self._trace(state, "Hybrid RAG Retriever", f"Retrieved {len(hits)} slides"),
            }

        def guard(state: ExamState) -> ExamState:
            # Reuse the dense scores already computed by the retriever instead of re-embedding the
            # whole corpus again — saves a GPU pass per question.
            hits = state.get("hits") or []
            score = max((hit["dense_score"] for hit in hits), default=0.0)
            relevant = score >= ONTOPIC_THRESHOLD
            return {
                "relevance": score,
                "refused": not relevant,
                "trace": self._trace(
                    state, "On-topic Guard", f"{'Passed' if relevant else 'Refused'} at {score:.3f}"
                ),
            }

        def route_guard(state: ExamState) -> str:
            return "refuse" if state.get("refused") else "generator"

        def refuse(state: ExamState) -> ExamState:
            return {
                "final_mcq": {
                    "refused": True,
                    "question": f"Cannot generate a question for '{state['topic']}': outside course notes.",
                    "disclaimer": DISCLAIMER,
                },
                "trace": self._trace(state, "Refusal Agent", "Stopped off-syllabus generation"),
            }

        def generator(state: ExamState) -> ExamState:
            mcq = self._generate_with_ft(state["context"], state["spec"])
            return {
                "mcq": mcq,
                "attempts": state.get("attempts", 0) + 1,
                "trace": self._trace(state, "Fine-tuned Generator", "Generated MCQ"),
            }

        def distractor(state: ExamState) -> ExamState:
            mcq = state["mcq"]
            if not isinstance(mcq, dict):
                return {"mcq": mcq, "trace": self._trace(state, "Distractor Specialist", "Skipped invalid draft")}
            improved = self._distractor_specialist(mcq, state.get("context", ""))
            return {
                "mcq": improved,
                "trace": self._trace(state, "Distractor Specialist", "Rewrote wrong options with bank misconceptions"),
            }

        def critic(state: ExamState) -> ExamState:
            report = critique(state["mcq"])
            mcq = report["mcq"]
            reasons = list(report["reasons"])
            hard = report["hard_fail"]
            examiner = {}
            if not hard:
                examiner = self._examiner_review(mcq, state.get("context", ""))
                if examiner.get("verdict") == "fail":
                    hard = True
                    reasons += [f"examiner: {x}" for x in (examiner.get("issues") or ["failed"])]
            return {
                "mcq": mcq,
                "critic": {"hard_fail": hard, "reasons": reasons, "mcq": mcq},
                "examiner": examiner,
                "trace": self._trace(state, "Critic and Examiner", "; ".join(reasons) or "Passed"),
            }

        def route(state: ExamState) -> str:
            return (
                "generator"
                if state["critic"]["hard_fail"] and state["attempts"] < MAX_RETRIES
                else "rebalance"
            )

        def rebalance(state: ExamState) -> ExamState:
            mcq = state["mcq"]
            if any("length bias" in reason for reason in state["critic"].get("reasons", [])):
                mcq = self._rebalance_distractors(mcq, state.get("context", ""))
                mcq = critique(mcq)["mcq"]
            return {"mcq": mcq, "trace": self._trace(state, "Rebalance Agent", "Checked final option balance")}

        def finalize(state: ExamState) -> ExamState:
            mcq = shuffle_mcq(state["mcq"])
            mcq["evidence_slide_ids"] = [hit["slide_id"] for hit in state["hits"]]
            mcq["disclaimer"] = DISCLAIMER
            return {
                "final_mcq": mcq,
                "trace": self._trace(state, "Finalize and Shuffle", "Citations attached and answers shuffled"),
            }

        graph = StateGraph(ExamState)
        for name, node in (
            ("planner", planner),
            ("retriever", retriever),
            ("guard", guard),
            ("refuse", refuse),
            ("generator", generator),
            ("distractor", distractor),
            ("critic", critic),
            ("rebalance", rebalance),
            ("finalize", finalize),
        ):
            graph.add_node(name, node)
        graph.set_entry_point("planner")
        graph.add_edge("planner", "retriever")
        graph.add_edge("retriever", "guard")
        graph.add_conditional_edges("guard", route_guard, {"generator": "generator", "refuse": "refuse"})
        graph.add_edge("refuse", END)
        graph.add_edge("generator", "distractor")
        graph.add_edge("distractor", "critic")
        graph.add_conditional_edges("critic", route, {"generator": "generator", "rebalance": "rebalance"})
        graph.add_edge("rebalance", "finalize")
        graph.add_edge("finalize", END)
        self._graph = graph.compile()

    # ---- Public exam generation --------------------------------------------------------
    def _run_one(self, spec: dict[str, Any], lecture: int | None) -> dict[str, Any]:
        state = self._graph.invoke(
            {"topic": spec["concept"], "requested_spec": spec, "lecture": lecture, "trace": []}
        )
        if state["final_mcq"].get("refused"):
            raise RuntimeError(state["final_mcq"]["question"])
        saved = self.save_approved_mcq(state["final_mcq"])
        return {
            "mcq": state["final_mcq"],
            "trace": state["trace"],
            "attempts": state["attempts"],
            "critic": state.get("critic", {}),
            "examiner": state.get("examiner", {}),
            "bank_save": saved,
        }

    def generate_exam(self, config: dict[str, Any], concepts: list[str]) -> list[dict[str, Any]]:
        self.initialize()
        count = int(config["count"])
        lecture = config.get("lecture")
        lecture = int(lecture) if lecture not in ("all", "", None) else None
        selected_concepts = (
            [config.get("concept")] * count
            if config.get("concept")
            else [concepts[index % len(concepts)] for index in range(count)]
        )
        try:
            blueprint = self._gemini_json(
                f"Concepts: {selected_concepts}\nQuestion count: {count}\nCreate the balanced blueprint.",
                BLUEPRINT_SYSTEM,
            ).get("items", [])
        except Exception:
            blueprint = []
        specs = []
        for index, concept in enumerate(selected_concepts):
            planned = blueprint[index] if index < len(blueprint) and isinstance(blueprint[index], dict) else {}
            specs.append(
                {
                    "concept": planned.get("concept", concept),
                    "difficulty": config["difficulty"]
                    if config["difficulty"] != "Mix"
                    else planned.get("difficulty", DIFFS[index % len(DIFFS)]),
                    "bloom_level": config["bloom"]
                    if config["bloom"] != "Mix"
                    else planned.get("bloom_level", BLOOMS[index % len(BLOOMS)]),
                    "question_type": config["question_type"]
                    if config["question_type"] != "Mix"
                    else planned.get("question_type", TYPES[index % len(TYPES)]),
                    "retrieval_query": planned.get("retrieval_query", concept),
                }
            )
        workers = min(GEN_WORKERS, len(specs)) or 1
        if workers == 1:
            return [self._run_one(spec, lecture) for spec in specs]
        results: list[Any] = [None] * len(specs)
        errors: list[Exception] = []
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(self._run_one, spec, lecture): i for i, spec in enumerate(specs)}
            for future in futures:
                i = futures[future]
                try:
                    results[i] = future.result()
                except Exception as exc:  # collect failures; keep the questions that succeeded
                    errors.append(exc)
        produced = [r for r in results if r is not None]
        if not produced:
            raise RuntimeError(str(errors[0]) if errors else "Generation failed.")
        return produced

    # ---- Tools -------------------------------------------------------------------------
    def question_bank_lookup(self, concept: str = "", difficulty: str = "", k: int = 3) -> list[dict[str, Any]]:
        """Return source-bank MCQs filtered by concept and difficulty."""
        frame = self.mcq_df
        if difficulty:
            frame = frame[frame["difficulty"].astype(str).str.lower() == difficulty.lower()]
        if concept:
            frame = frame[frame["tested_concepts"].astype(str).str.contains(concept, case=False, na=False)]
        return frame.head(k)[["question", "difficulty", "bloom_level"]].to_dict("records")

    def slide_lookup_tool(self, slide_id: str) -> dict[str, Any]:
        """Open exact lecture-slide evidence by ID such as L5-S43."""
        chunk = self.slide_by_id.get(slide_id)
        if not chunk:
            return {"error": f"{slide_id} not found"}
        return {"slide_id": slide_id, "title": chunk["metadata"]["slide_title"], "text": chunk["text"]}

    def youtube_search(self, query: str) -> list[dict[str, str]]:
        """Search YouTube for educational videos about a course concept."""
        key = os.getenv("YT_API_KEY") or YT_API_KEY_FALLBACK
        if not key:
            return [
                {
                    "title": f"YouTube results for: {query}",
                    "url": "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query),
                }
            ]
        try:
            url = (
                "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=3"
                f"&q={urllib.parse.quote(query)}&key={key}"
            )
            with urllib.request.urlopen(url, timeout=15) as response:
                data = json.load(response)
            items = [
                {"title": item["snippet"]["title"], "url": f"https://youtu.be/{item['id']['videoId']}"}
                for item in data.get("items", [])
            ]
            if items:
                return items
        except Exception:
            pass
        return [
            {
                "title": f"YouTube results for: {query}",
                "url": "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query),
            }
        ]

    def save_approved_mcq(self, mcq: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(mcq, dict) or mcq.get("refused") or "question" not in mcq:
            return {"saved": False, "reason": "not a valid MCQ"}
        with self._infer_lock:
            vector = self._embedder.encode(
                [f"query: {mcq.get('question', '')}"], normalize_embeddings=True, convert_to_numpy=True
            )[0].astype("float32")
        with self._bank_lock, sqlite3.connect(BANK_DB_PATH) as conn:
            for row_id, blob in conn.execute(
                "SELECT id, embedding FROM approved_mcqs WHERE embedding IS NOT NULL"
            ):
                stored = np.frombuffer(blob, dtype="float32")
                if stored.shape == vector.shape and float(vector @ stored) >= DUP_THRESHOLD:
                    return {"saved": False, "reason": "near-duplicate", "similar_to_id": row_id}
            evidence = mcq.get("evidence_slide_ids") or []
            lecture_match = re.search(r"L(\d+)-S\d+", str(evidence))
            cursor = conn.execute(
                """INSERT INTO approved_mcqs
                (lecture,concept,difficulty,bloom_level,question_type,question,options,correct_letter,
                correct_answer,evidence_slide_ids,why_correct,embedding,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    int(lecture_match.group(1)) if lecture_match else None,
                    str((mcq.get("tested_concepts") or [""])[0]),
                    mcq.get("difficulty"),
                    mcq.get("bloom_level"),
                    mcq.get("question_type"),
                    mcq.get("question"),
                    json.dumps(mcq.get("options") or {}),
                    mcq.get("correct_letter"),
                    mcq.get("correct_answer"),
                    json.dumps(evidence),
                    mcq.get("why_correct"),
                    vector.tobytes(),
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            return {"saved": True, "id": cursor.lastrowid}

    def bank_stats(self) -> dict[str, Any]:
        with sqlite3.connect(BANK_DB_PATH) as conn:
            total = conn.execute("SELECT COUNT(*) FROM approved_mcqs").fetchone()[0]
            by_lecture = dict(conn.execute("SELECT lecture,COUNT(*) FROM approved_mcqs GROUP BY lecture"))
        return {"total": total, "by_lecture": by_lecture}

    def question_bank_practice(
        self, concept: str = "", difficulty: str = "", lecture: int | None = None, k: int = 5
    ) -> list[dict[str, Any]]:
        """Retrieve Critic/Examiner-approved MCQs from the persistent SQLite bank."""
        sql = (
            "SELECT lecture,concept,difficulty,question_type,question,options,correct_letter "
            "FROM approved_mcqs WHERE 1=1"
        )
        args: list[Any] = []
        if concept:
            sql += " AND lower(concept) LIKE ?"
            args.append(f"%{concept.lower()}%")
        if difficulty:
            sql += " AND lower(difficulty)=?"
            args.append(difficulty.lower())
        if lecture is not None:
            sql += " AND lecture=?"
            args.append(int(lecture))
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(int(k))
        with sqlite3.connect(BANK_DB_PATH) as conn:
            rows = conn.execute(sql, args).fetchall()
        return [
            {
                "lecture": row[0],
                "concept": row[1],
                "difficulty": row[2],
                "question_type": row[3],
                "question": row[4],
                "options": json.loads(row[5] or "{}"),
                "correct_letter": row[6],
            }
            for row in rows
        ]

    # ---- Student-facing feedback -------------------------------------------------------
    def feedback_tutor(self, mcq: dict[str, Any], student_answer: list[str]) -> dict[str, Any]:
        self.initialize()
        hits = self._retrieve(mcq["question"], None, k=4)
        evidence = self._build_context(hits)
        options = mcq.get("options") or {}
        chosen_letters = _norm_letters(student_answer)
        chosen = "; ".join(f"{L}) {options.get(L, '(no such option)')}" for L in chosen_letters) or "(no answer)"
        text = self._gemini_text(
            f"Question: {mcq['question']}\nStudent chose: {chosen}\n"
            f"Correct: {mcq.get('correct_letter', '')}) {mcq.get('correct_answer', '')}\n\n"
            f"Slide evidence:\n{evidence}\n\nExplain, citing slide IDs.",
            TUTOR_SYSTEM,
        )
        return {"text": text, "evidence": evidence, "hits": hits}

    def answer_question(
        self, mcq: dict[str, Any], student_answer: list[str], is_correct: bool | None = None
    ) -> dict[str, Any]:
        correct = (
            is_correct
            if is_correct is not None
            else set(_norm_letters(mcq.get("correct_letter"))) == set(_norm_letters(student_answer))
        )
        feedback = self.feedback_tutor(mcq, student_answer)
        text = feedback["text"] or ""
        cited = re.findall(r"L\d+-S\d+", text)
        grounded = self._verify_groundedness(text, feedback["evidence"], cited)
        if not grounded["ok"]:
            text += (
                "\n\n[Groundedness warning] Parts of this explanation may not be fully supported by "
                "the cited slides; please verify against the originals."
            )
            if grounded["missing_slide_ids"]:
                text += f" Unknown slide IDs cited: {grounded['missing_slide_ids']}."
        output: dict[str, Any] = {
            "correct": correct,
            "feedback": ("Correct! " + text) if correct else text,
            "groundedness": grounded,
        }
        if not correct:
            # Search by the TESTED CONCEPT (not the whole question) so application-style stems still
            # return on-topic videos, and always return at least one link deterministically.
            concepts = [c for c in (mcq.get("tested_concepts") or []) if c]
            concept = ", ".join(concepts) or str(mcq.get("question", ""))[:80]
            videos = self.youtube_search(f"{concept} explained")[:2]
            output["resources"] = videos
            try:
                titles = "; ".join(v.get("title", "") for v in videos)
                output["resources_note"] = self._gemini_text(
                    f"A student answered a Generative-AI question on '{concept}' incorrectly. "
                    f"In ONE short, encouraging sentence, tell them what to focus on while watching a "
                    f"video about this concept. Candidate videos: {titles}",
                    RECO_SYSTEM,
                )
            except Exception:
                pass
        return output

    def course_chat(self, query: str, lecture: int | None = None, grounded: bool = True) -> dict[str, Any]:
        self.initialize()
        if not grounded:
            # Ungrounded baseline: answer from the model alone, WITHOUT the RAG retrieval tool.
            # Exposed so the difference the retrieval tool makes is visible (rubric: tool impact).
            answer = self._gemini_text(
                f"Answer this Generative-AI course question from general knowledge:\n{query}",
                "You are a teaching assistant. Answer concisely. You have NO access to the course "
                "slides, so do not cite slide IDs.",
            )
            return {
                "answer": answer,
                "sources": [],
                "refused": False,
                "grounded": False,
                "disclaimer": "Ungrounded answer (RAG retrieval tool OFF) — not verified against your lecture notes.",
            }
        hits = self._retrieve(query, lecture, k=5)
        score = max((hit["dense_score"] for hit in hits), default=0.0)
        if not hits or score < ONTOPIC_THRESHOLD:
            return {
                "answer": "I could not find enough support for that question in the course lectures.",
                "sources": [],
                "refused": True,
                "disclaimer": DISCLAIMER,
            }
        evidence = self._build_context(hits)
        answer = self._gemini_text(
            f"Student question: {query}\n\nLecture evidence:\n{evidence}\n\n"
            "Explain clearly, use LaTeX for equations, and cite slide IDs.",
            TUTOR_SYSTEM,
        )
        check = self._verify_groundedness(answer, evidence, re.findall(r"L\d+-S\d+", answer))
        if not check["ok"]:
            answer += "\n\n[Groundedness warning] Verify unsupported parts against the original slides."
        return {
            "answer": answer,
            "sources": hits,
            "refused": False,
            "grounded": True,
            "groundedness": check,
            "disclaimer": DISCLAIMER,
        }

    def progress_report(self, summary: dict[str, Any]) -> str:
        self.initialize()
        return self._gemini_text(
            json.dumps(summary) + "\n\nGive the revision plan.",
            PROGRESS_SYSTEM,
            tools=[self.slide_lookup_tool, self.question_bank_lookup, self.youtube_search],
        )


multi_agent_runtime = MultiAgentRuntime()
