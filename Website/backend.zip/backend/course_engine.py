from __future__ import annotations

import json
import os
import random
import re
import threading
import urllib.parse
import uuid
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

PROJECT_ROOT = Path(os.getenv("PROJECT_ROOT", Path(__file__).resolve().parents[2])).expanduser().resolve()


def _first_existing(*paths: Path) -> Path:
    for path in paths:
        if path.exists():
            return path
    return paths[0]


MCQ_PATH = _first_existing(
    PROJECT_ROOT / "Dataset" / "MCQ Exams" / "llm_mcq_exam_bank.xlsx",
    PROJECT_ROOT / "Dataset" / "MCQ Exam" / "llm_mcq_exam_bank.xlsx",
)
CHUNKS_PATH = _first_existing(
    PROJECT_ROOT / "RAG" / "chunks_metadata.json",
    PROJECT_ROOT / "RAG" / "Embeddings" / "chunks_metadata.json",
)
REPORTS_PATH = PROJECT_ROOT / "website" / "data" / "reports.json"
DISCLAIMER = (
    "AI-assisted explanations are grounded in the course lecture notes. "
    "Always verify important details against the original slides and your instructor."
)

DIFFICULTIES = ["Beginner", "Intermediate", "Difficult"]
BLOOMS = ["Remember", "Understand", "Apply", "Analyze", "Evaluate", "Create"]
QUESTION_TYPES = ["single_answer", "true_false", "multi_answer"]
TOKEN_RE = re.compile(r"[a-z0-9][a-z0-9+\-]*")
SLIDE_RE = re.compile(r"L(\d+)-S(\d+)", re.I)


def _tokens(text: str) -> list[str]:
    return TOKEN_RE.findall(str(text).lower())


def _parse_lettered(blob: Any) -> dict[str, str]:
    if not isinstance(blob, str):
        return {}
    result: dict[str, str] = {}
    current = None
    for raw in blob.splitlines():
        match = re.match(r"^\s*([A-Z])[.)]\s*(.+?)\s*$", raw)
        if match:
            current = match.group(1)
            result[current] = match.group(2).strip()
        elif current and raw.strip():
            result[current] += " " + raw.strip()
    return result


def _letters(value: Any) -> list[str]:
    return sorted(set(re.findall(r"[A-Z]", str(value).upper())))


def _slide_ids(value: Any) -> list[str]:
    return [f"L{a}-S{b}" for a, b in SLIDE_RE.findall(str(value))]


def _lecture(value: Any) -> int | None:
    found = SLIDE_RE.search(str(value))
    return int(found.group(1)) if found else None


class CourseEngine:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.questions = self._load_questions()
        self.question_by_id = {q["id"]: q for q in self.questions}
        self.chunks = self._load_chunks()
        self.slide_by_id = {c["id"]: c for c in self.chunks}
        self.lecture_concepts = self._build_lecture_concepts()
        self.idf = self._build_idf()
        self.reports = self._load_reports()

    def _load_questions(self) -> list[dict[str, Any]]:
        frame = pd.read_excel(MCQ_PATH, sheet_name="MCQ_Bank").fillna("")
        output = []
        for i, row in frame.iterrows():
            evidence = _slide_ids(row["evidence_slide_ids"])
            concepts = [x.strip() for x in re.split(r"[;,]", str(row["tested_concepts"])) if x.strip()]
            output.append(
                {
                    "id": str(row["question_id"] or f"Q-{i + 1}"),
                    "question": str(row["question"]).strip(),
                    "question_type": str(row["question_type"]).strip() or "single_answer",
                    "options": _parse_lettered(row["options"]),
                    "correct_letters": _letters(row["correct_letter"]),
                    "correct_answer": str(row["correct_answer"]).strip(),
                    "difficulty": str(row["difficulty"]).strip() or "Intermediate",
                    "bloom_level": str(row["bloom_level"]).strip() or "Understand",
                    "concepts": concepts,
                    "evidence_slide_ids": evidence,
                    "lecture": _lecture(row["evidence_slide_ids"]),
                    "why_correct": str(row["why_correct"]).strip(),
                    "why_wrong": _parse_lettered(row["why_each_wrong_option_is_plausible"]),
                }
            )
        return output

    def _load_chunks(self) -> list[dict[str, Any]]:
        raw = json.loads(CHUNKS_PATH.read_text(encoding="utf-8"))
        chunks = []
        for chunk in raw:
            meta = chunk["metadata"]
            text = str(chunk["text"])
            chunks.append(
                {
                    "id": chunk["id"],
                    "text": text,
                    "title": meta["slide_title"],
                    "lecture": int(meta["lecture"]),
                    "slide_number": int(meta["slide_number"]),
                    "concepts": meta.get("key_concepts", []),
                    "tokens": Counter(_tokens(text)),
                }
            )
        return chunks

    def _build_lecture_concepts(self) -> dict[int, list[str]]:
        values: dict[int, list[str]] = defaultdict(list)
        for chunk in self.chunks:
            for concept in chunk["concepts"]:
                if concept and concept not in values[chunk["lecture"]]:
                    values[chunk["lecture"]].append(concept)
        return dict(values)

    def _build_idf(self) -> dict[str, float]:
        docs = len(self.chunks)
        freq = Counter()
        for chunk in self.chunks:
            freq.update(chunk["tokens"].keys())
        return {term: 1.0 + (docs / (1 + count)) for term, count in freq.items()}

    def _load_reports(self) -> list[dict[str, Any]]:
        if REPORTS_PATH.exists():
            try:
                return json.loads(REPORTS_PATH.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return []

    def _save_reports(self) -> None:
        REPORTS_PATH.parent.mkdir(parents=True, exist_ok=True)
        REPORTS_PATH.write_text(json.dumps(self.reports[-100:], indent=2), encoding="utf-8")

    def overview(self) -> dict[str, Any]:
        per_lecture = Counter(q["lecture"] for q in self.questions if q["lecture"])
        return {
            "lectures": [
                {
                    "number": lecture,
                    "questions": per_lecture[lecture],
                    "slides": sum(c["lecture"] == lecture for c in self.chunks),
                    "concepts": self.lecture_concepts.get(lecture, [])[:6],
                }
                for lecture in sorted(self.lecture_concepts)
            ],
            "total_questions": len(self.questions),
            "total_slides": len(self.chunks),
            "reports": self.reports[-5:][::-1],
            "difficulty_counts": Counter(q["difficulty"] for q in self.questions),
            "bloom_counts": Counter(q["bloom_level"] for q in self.questions),
            "disclaimer": DISCLAIMER,
        }

    def search_questions(
        self,
        lecture: int | None = None,
        difficulty: str = "",
        bloom: str = "",
        question_type: str = "",
        query: str = "",
        limit: int = 40,
        include_answers: bool = True,
    ) -> list[dict[str, Any]]:
        terms = set(_tokens(query))
        matches = []
        for q in self.questions:
            if lecture and q["lecture"] != lecture:
                continue
            if difficulty and difficulty != "Mix" and q["difficulty"].lower() != difficulty.lower():
                continue
            if bloom and bloom != "Mix" and q["bloom_level"].lower() != bloom.lower():
                continue
            if question_type and question_type != "Mix" and q["question_type"] != question_type:
                continue
            if terms:
                haystack = set(_tokens(q["question"] + " " + " ".join(q["concepts"])))
                if not terms.intersection(haystack):
                    continue
            item = dict(q)
            if not include_answers:
                for key in ("correct_letters", "correct_answer", "why_correct", "why_wrong"):
                    item.pop(key, None)
            matches.append(item)
        return matches[: max(1, min(limit, 100))]

    def generate_exam(self, config: dict[str, Any]) -> dict[str, Any]:
        count = max(1, min(int(config.get("count", 10)), 25))
        lecture = config.get("lecture")
        lecture = int(lecture) if lecture not in (None, "", "all") else None
        if config.get("mode", "multi_agent") == "multi_agent":
            return self._generate_multi_agent_exam(config, count, lecture)
        pool = self.search_questions(
            lecture=lecture,
            difficulty=str(config.get("difficulty", "Mix")),
            bloom=str(config.get("bloom", "Mix")),
            question_type=str(config.get("question_type", "Mix")),
            query=str(config.get("concept", "")),
            limit=100,
            include_answers=True,
        )
        if len(pool) < count:
            pool = self.search_questions(lecture=lecture, query=str(config.get("concept", "")), limit=100)
        if not pool:
            raise ValueError("No questions match this exam configuration.")
        selected = random.sample(pool, min(count, len(pool)))
        exam_id = f"exam-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}"
        return {
            "exam_id": exam_id,
            "config": config,
            "questions": [self._student_question(q) for q in selected],
            "available": len(pool),
            "disclaimer": DISCLAIMER,
            "generation_mode": "question_bank",
        }

    def _generate_multi_agent_exam(
        self, config: dict[str, Any], count: int, lecture: int | None
    ) -> dict[str, Any]:
        from .multi_agent_runtime import multi_agent_runtime

        concepts = self.lecture_concepts.get(lecture, []) if lecture else [
            concept
            for lecture_number in sorted(self.lecture_concepts)
            for concept in self.lecture_concepts[lecture_number]
        ]
        if not concepts:
            raise ValueError("No course concepts are available for this scope.")
        generated = multi_agent_runtime.generate_exam({**config, "count": count}, concepts)
        questions = []
        for item in generated:
            mcq = item["mcq"]
            question_id = f"GEN-{uuid.uuid4().hex[:12]}"
            evidence = mcq.get("evidence_slide_ids") or []
            internal = {
                "id": question_id,
                "question": str(mcq.get("question", "")),
                "question_type": str(mcq.get("question_type", "single_answer")),
                "options": mcq.get("options") or {},
                "correct_letters": _letters(mcq.get("correct_letter", "")),
                "correct_answer": str(mcq.get("correct_answer", "")),
                "difficulty": str(mcq.get("difficulty", "Intermediate")),
                "bloom_level": str(mcq.get("bloom_level", "Apply")),
                "concepts": mcq.get("tested_concepts") or [config.get("concept") or "Course concept"],
                "evidence_slide_ids": evidence,
                "lecture": _lecture(" ".join(evidence)) or lecture,
                "why_correct": str(mcq.get("why_correct", "")),
                "why_wrong": mcq.get("why_each_wrong_option_is_plausible") or {},
                "agent_trace": item["trace"],
                "attempts": item["attempts"],
                "critic": item["critic"],
                "examiner": item["examiner"],
                "generated_by_multi_agent": True,
            }
            self.question_by_id[question_id] = internal
            questions.append(self._student_question(internal))
        return {
            "exam_id": f"exam-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}",
            "config": config,
            "questions": questions,
            "available": len(questions),
            "generation_mode": "fine_tuned_multi_agent",
            "disclaimer": DISCLAIMER,
        }

    @staticmethod
    def _student_question(q: dict[str, Any]) -> dict[str, Any]:
        output = {
            key: q[key]
            for key in (
                "id",
                "question",
                "question_type",
                "options",
                "difficulty",
                "bloom_level",
                "concepts",
                "lecture",
            )
        }
        if q.get("agent_trace"):
            output["agent_trace"] = q["agent_trace"]
            output["attempts"] = q.get("attempts", 1)
        return output

    def submit_exam(self, payload: dict[str, Any]) -> dict[str, Any]:
        responses = payload.get("responses", [])
        details = []
        lecture_totals: dict[int, list[int]] = defaultdict(lambda: [0, 0])
        concept_totals: dict[str, list[int]] = defaultdict(lambda: [0, 0])
        correct_count = 0
        agent_jobs: list[tuple[int, dict[str, Any], list[str]]] = []
        for response in responses:
            q = self.question_by_id.get(str(response.get("question_id")))
            if not q:
                continue
            chosen = _letters(response.get("answer", []))
            correct = chosen == q["correct_letters"]
            correct_count += int(correct)
            if q["lecture"]:
                lecture_totals[q["lecture"]][0] += int(correct)
                lecture_totals[q["lecture"]][1] += 1
            for concept in q["concepts"][:2]:
                concept_totals[concept][0] += int(correct)
                concept_totals[concept][1] += 1
            details.append(
                {
                    "question_id": q["id"],
                    "question": q["question"],
                    "options": q.get("options", {}),
                    "chosen": chosen,
                    "correct": correct,
                    "correct_letters": q["correct_letters"],
                    "correct_answer": q["correct_answer"],
                    "explanation": q["why_correct"],
                    "why_wrong": q.get("why_wrong") or {},
                    "evidence_slide_ids": q["evidence_slide_ids"],
                    "lecture": q["lecture"],
                    "concepts": q["concepts"],
                }
            )
            if q.get("generated_by_multi_agent"):
                # Hand the agent a raw-MCQ-shaped payload (correct_letter / tested_concepts), not the
                # engine's internal shape — otherwise the recommender loses the concept and searches
                # the whole question text, returning irrelevant videos.
                mcq_payload = {
                    "question": q["question"],
                    "options": q.get("options", {}),
                    "question_type": q.get("question_type", "single_answer"),
                    "correct_letter": ",".join(q["correct_letters"]),
                    "correct_answer": q["correct_answer"],
                    "tested_concepts": q.get("concepts") or [],
                    "why_correct": q.get("why_correct", ""),
                    "evidence_slide_ids": q.get("evidence_slide_ids", []),
                }
                agent_jobs.append((len(details) - 1, mcq_payload, chosen, correct))
        # Run the grounded Feedback Tutor + resource recommender concurrently across questions so
        # the multi-agent feedback (why-wrong + YouTube) does not serialize one Gemini call per item.
        if agent_jobs:
            try:
                from .multi_agent_runtime import multi_agent_runtime

                def _feedback(job: tuple[int, dict[str, Any], list[str], bool]) -> tuple[int, dict[str, Any] | None]:
                    index, question, chosen_letters, was_correct = job
                    try:
                        return index, multi_agent_runtime.answer_question(question, chosen_letters, was_correct)
                    except Exception:
                        return index, None

                with ThreadPoolExecutor(max_workers=min(4, len(agent_jobs))) as pool:
                    for index, agent_feedback in pool.map(_feedback, agent_jobs):
                        if not agent_feedback:
                            continue
                        details[index]["explanation"] = agent_feedback["feedback"]
                        details[index]["groundedness"] = agent_feedback["groundedness"]
                        if agent_feedback.get("resources"):
                            details[index]["resources"] = agent_feedback["resources"]
                        if agent_feedback.get("resources_note"):
                            details[index]["resources_note"] = agent_feedback["resources_note"]
            except Exception:
                pass
        total = len(details)
        score = round(correct_count / total * 100) if total else 0
        weak_lectures = [
            lecture
            for lecture, counts in sorted(lecture_totals.items(), key=lambda x: x[1][0] / x[1][1])
            if counts[0] / counts[1] < 0.7
        ]
        weak_concepts = [
            concept
            for concept, counts in sorted(concept_totals.items(), key=lambda x: x[1][0] / x[1][1])
            if counts[0] / counts[1] < 0.7
        ][:6]
        feedback = self._progress_feedback(score, weak_lectures, weak_concepts)
        if any(self.question_by_id.get(str(r.get("question_id")), {}).get("generated_by_multi_agent") for r in responses):
            try:
                from .multi_agent_runtime import multi_agent_runtime

                feedback = multi_agent_runtime.progress_report(
                    {
                        "score": score,
                        "correct": correct_count,
                        "total": total,
                        "weak_lectures": weak_lectures,
                        "weak_concepts": weak_concepts,
                    }
                )
            except Exception:
                pass
        report = {
            "id": f"report-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "score": score,
            "correct": correct_count,
            "total": total,
            "weak_lectures": weak_lectures,
            "weak_concepts": weak_concepts,
            "by_lecture": {
                str(key): {"correct": val[0], "total": val[1], "accuracy": round(val[0] / val[1] * 100)}
                for key, val in lecture_totals.items()
            },
            "feedback": feedback,
            "details": details,
            "disclaimer": DISCLAIMER,
        }
        with self._lock:
            self.reports.append(report)
            self._save_reports()
        return report

    @staticmethod
    def _progress_feedback(score: int, lectures: list[int], concepts: list[str]) -> str:
        if score >= 85:
            opening = "Excellent command of the material. Your next step is deeper application and analysis."
        elif score >= 70:
            opening = "You have a solid foundation. A focused review should close the remaining gaps."
        elif score >= 50:
            opening = "You understand several core ideas, but targeted revision will make the knowledge more dependable."
        else:
            opening = "Start with the fundamentals and build upward one lecture at a time."
        focus = []
        if lectures:
            focus.append("prioritize Lecture " + ", Lecture ".join(map(str, lectures[:3])))
        if concepts:
            focus.append("practice " + ", ".join(concepts[:4]))
        return opening + (" For your next session, " + " and ".join(focus) + "." if focus else "")

    def retrieve(self, query: str, lecture: int | None = None, k: int = 5) -> list[dict[str, Any]]:
        query_tokens = Counter(_tokens(query))
        if not query_tokens:
            return []
        query_set = set(query_tokens)
        scored = []
        for chunk in self.chunks:
            if lecture and chunk["lecture"] != lecture:
                continue
            overlap = query_set.intersection(chunk["tokens"])
            lexical = sum(chunk["tokens"][term] * self.idf.get(term, 1.0) for term in overlap)
            phrase = 3.0 if query.lower() in chunk["text"].lower() else 0.0
            concept_text = " ".join(chunk["concepts"]).lower()
            concept = sum(2.0 for term in query_set if term in concept_text)
            score = lexical + phrase + concept
            if score > 0:
                scored.append((score, chunk))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [
            {
                "slide_id": chunk["id"],
                "title": chunk["title"],
                "lecture": chunk["lecture"],
                "slide_number": chunk["slide_number"],
                "text": chunk["text"],
                "score": round(score, 2),
            }
            for score, chunk in scored[:k]
        ]

    def chat(self, query: str, lecture: int | None = None, grounded: bool = True) -> dict[str, Any]:
        from .multi_agent_runtime import multi_agent_runtime

        return multi_agent_runtime.course_chat(query, lecture, grounded)

    @staticmethod
    def _clean_excerpt(text: str, size: int = 650) -> str:
        value = re.sub(r"\s+", " ", text).strip()
        if "Key concepts:" in value:
            value = value.split("Key concepts:", 1)[0]
        return value[:size].rsplit(" ", 1)[0] + ("..." if len(value) > size else "")

    @staticmethod
    def _gemini_answer(query: str, hits: list[dict[str, Any]]) -> str | None:
        key = os.getenv("GEMINI_API_KEY")
        if not key:
            return None
        try:
            from google import genai

            context = "\n\n".join(f"[{h['slide_id']}] {h['text']}" for h in hits)
            prompt = (
                "Answer the student's question using only the supplied course context. "
                "Explain clearly, preserve mathematical notation using LaTeX, and cite claims "
                f"with [L#-S#].\n\nQuestion: {query}\n\nContext:\n{context}"
            )
            return genai.Client(api_key=key).models.generate_content(
                model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"), contents=prompt
            ).text
        except Exception:
            return None

    def slide_search(self, query: str = "", lecture: int | None = None, limit: int = 20) -> list[dict[str, Any]]:
        if query:
            return self.retrieve(query, lecture=lecture, k=limit)
        return [
            {
                "slide_id": c["id"],
                "title": c["title"],
                "lecture": c["lecture"],
                "slide_number": c["slide_number"],
                "text": c["text"],
            }
            for c in self.chunks
            if not lecture or c["lecture"] == lecture
        ][:limit]

    @staticmethod
    def youtube_recommendations(query: str) -> list[dict[str, str]]:
        topics = [
            f"{query} explained",
            f"{query} tutorial",
            f"{query} visual intuition",
        ]
        return [
            {
                "title": topic.title(),
                "url": "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(topic),
                "description": "Open curated YouTube search results for this course concept.",
            }
            for topic in topics
        ]


engine = CourseEngine()
